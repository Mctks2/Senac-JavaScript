try { Nome: Mega-Sena
    const response = await fetch ("resultado da Mega-Sena", "nº"209);
    const data = await response.json();

      const user = data.results[0,1,2,3,4,5];

 

      console.log('Nome: ' + user.numberResult + ' ' + user.numberGame);

      console.log(result);

   

    } catch (error) {

      console.error('Erro ao buscar os dados do resultado: ', error);

    }

  }
}